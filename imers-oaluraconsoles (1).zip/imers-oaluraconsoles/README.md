# Imersão - Alura - Consoles

A Pen created on CodePen.io. Original URL: [https://codepen.io/LuisGustavo-Dev-Code/pen/dyBgVJd](https://codepen.io/LuisGustavo-Dev-Code/pen/dyBgVJd).


 // dados.js //


let dados = [

  {

    titulo: "PlayStation 5",

    descricao: "O PlayStation 5 é a nova geração de consoles da Sony. Com gráficos incríveis e um desempenho poderoso, ele oferece uma experiência de jogo imersiva. Desfrute de jogos exclusivos e jogue online com seus amigos.",

    link: "https://www.playstation.com/pt-br/",

    anoLancamento: 2020,

    empresa: "Sony",
    
    class: "pS5",
    
    tags: "2020 ps5 "

  },

  {

    titulo: "Nintendo Switch",

    descricao: "O Nintendo Switch é um videogame super versátil! Você pode jogar na TV, como um console tradicional, ou levar ele para qualquer lugar e jogar no modo portátil. Tem jogos para todos os gostos, desde aventuras épicas até corridas divertidas. É perfeito para jogar sozinho ou com os amigos!",

    link: "https://www.nintendo.com/pt-br/switch/system/?srsltid=AfmBOorMt7dzYtuEkJvMyJQ6mTrckG7OI_bad8bizy4-oslEhLWuHhx85x",

    anoLancamento: 2017,

    empresa: "Nintendo",
    
    class: "ninSwitch",

    tags: "2017 Mario "
  },

  {

    titulo: "Xbox Series X",

    descricao: "O Xbox Series X é o console mais poderoso da Microsoft. Com jogos em 4K e 120fps, ele oferece uma experiência de jogo fluida e realista. Explore um vasto catálogo de jogos e jogue com seus amigos online.",

    link: "https://www.xbox.com/pt-br/",

    anoLancamento: 2020,

    empresa: "Microsoft",
    
    class: "xbox",

    tags: "2020 series one"
  },

  {

    titulo: "PlayStation 4",

    descricao: "O PlayStation 4 é um console de videogame de alta definição desenvolvido pela Sony Computer Entertainment. Com uma vasta biblioteca de jogos e recursos online, ele oferece uma experiência de jogo completa. Desfrute de jogos exclusivos e jogue online com seus amigos.",

    link: "https://www.playstation.com/pt-br/ps4/",

    anoLancamento: 2013,

    empresa: "Sony",
    
    class: "ps4",

    tags:"2013 ps4 "
  }

];

function pesquisar(){

//console.log(dados);

let section = document.getElementById("resultados-pesquisa");
  
let campoPesquisa = document.getElementById("campo-pesquisa").value;
  
 if(campoPesquisa == ""){
   section.innerHTML ="<p>Não há nada por aqui</p>";
   return 
 }
  
  campoPesquisa = campoPesquisa.toLowerCase();

let respostas = "";
let titulo = "";
let descricao = "";
let tags = "";

for(let dado of dados) {
  
  titulo = dado.titulo.toLowerCase();
  descricao = dado.descricao.toLowerCase();
  tags = dado.tags.toLowerCase();
  
  if (titulo.includes(campoPesquisa) || descricao.includes(campoPesquisa) || tags.includes(campoPesquisa)){

respostas += `<div class="item-resultado ${dado.class}">

      <h2>

        <a href="#" target="_blank">${dado.titulo}</a>

      </h2>

      <p class="descricao-meta ">${dado.descricao}</p>
      
  <p class="descricao-meta">${dado.anoLancamento}</p>

      <a href =${dado.link} target="_blank">Mais informações</a>

        </div>`}
}
  
if (!respostas){
 respostas = "<p>Nenhum console foi encontrado</p>";
}  
  
section.innerHTML = respostas;
}
